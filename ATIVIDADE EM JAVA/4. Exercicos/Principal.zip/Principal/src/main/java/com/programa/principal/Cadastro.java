/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.programa.principal;

import java.util.Scanner;

/**
 *
 * @author dti
 */
public class Cadastro 
{
    private static Scanner aluno = new Scanner (System.in);
     
    private static int idade;
    
    private static float altura;
    
    private static String nome;
    
    private static boolean estrangeiro;
    
    private static void main(String args[])
    {
        System.out.println("Seja bem-vindo a aplicação de cadastro... ^-^");
        
        System.out.println("Digite seu nome: ");
    }
            
}